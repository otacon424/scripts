Language {#language}
=======

The Language object handles all readable text produced by the software.

See [MediaWiki.org](https://www.mediawiki.org/wiki/Localisation#General_use_.28for_developers.29)
for documentation relating to using localized messages.
