<?php
namespace MediaWiki\Notification;

use RuntimeException;

/**
 * @internal
 */
class MiddlewareException extends RuntimeException {
}
